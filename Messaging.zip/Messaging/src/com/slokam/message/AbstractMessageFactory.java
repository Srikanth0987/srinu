package com.slokam.message;

public  abstract class AbstractMessageFactory {
     
	public static MessageFactoryInterface getMessageFactory(String channel ){
		MessageFactoryInterface factory = null;
		switch(channel){
			  case  "mail" : factory = new MailMessageFactory(); break;
			  case  "sms"  : factory = new SMSMessageFactory(); break;
			  case  "faceBook": factory = new FaceBookMessageFactory(); break;
		}
		return factory;
	}
}
