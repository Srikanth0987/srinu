package com.slokam.message;

public class FaceBook implements Message{

	@Override
	public void send() {
		System.out.println(" sending FaceBook message");
	}
}
