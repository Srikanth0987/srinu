package com.slokam.message;

public class SMS implements Message{
  
	@Override
	public void send() {
		System.out.println("Sending SMS ...");
	}
	
}
