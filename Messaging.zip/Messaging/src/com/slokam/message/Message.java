package com.slokam.message;

public interface Message {
	public void send();
}
