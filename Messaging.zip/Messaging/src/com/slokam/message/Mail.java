package com.slokam.message;

public class Mail implements Message {
	@Override
	public void send() {
		
		System.out.println("Sending Mail ....");
	}
}
