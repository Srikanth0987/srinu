package com.slokam.message;

public interface MessageFactoryInterface {
	 public Message getMessageObject();
}
