package com.slokam.message;

public class Main {

	public static void main(String[] args) {
		
		Student std = new Student();
		
		MessageFactoryInterface factory = AbstractMessageFactory.getMessageFactory(std.getPreCommCha());
		Message message =  factory.getMessageObject();
		message.send();
		
	}
}
