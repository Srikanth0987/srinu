package com.slokam.message;

public class MailMessageFactory implements MessageFactoryInterface{
 
	@Override
	public Message getMessageObject() {
		Mail mail = new Mail();
		return mail;
	}
	
}  
