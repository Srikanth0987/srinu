package com.slokam.message;

public class FaceBookMessageFactory implements MessageFactoryInterface {

	@Override
	public Message getMessageObject() {
		FaceBook faceBook = new FaceBook();
		return faceBook;
	}
	
}
