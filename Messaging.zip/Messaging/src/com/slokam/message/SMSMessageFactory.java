package com.slokam.message;

public class SMSMessageFactory implements MessageFactoryInterface{

	@Override
	public Message getMessageObject() {
		SMS sms = new SMS();
		return sms;
	}
	
}
